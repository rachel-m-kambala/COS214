//MUKAJI MWENI RACHEL KAMBALA u23559129
//JERUSHA THAVER u23686376

#ifndef FAMILYDISCOUNT_H
#define FAMILYDISCOUNT_H

#include "DiscountStrategy.h"

class FamilyDiscount : public DiscountStrategy {
public:
    double applyDiscount(double price, int quantity);
};


#endif
