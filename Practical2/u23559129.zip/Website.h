//MUKAJI MWENI RACHEL KAMBALA u23559129
//JERUSHA THAVER u23686376

#ifndef WEBSITE_H
#define WEBSITE_H

#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <list>
#include "Observer.h"

class Website : public Observer {
    public:
        void update(std::string message);

};

#endif