//MUKAJI MWENI RACHEL KAMBALA u23559129
//JERUSHA THAVER u23686376

#include "Website.h"

void Website::update(std::string message) {
    std::cout << "Website Notification: " << message << std::endl;
};