//MUKAJI MWENI RACHEL KAMBALA u23559129
//JERUSHA THAVER u23686376

#include "RegularPrice.h"

double RegularPrice::applyDiscount(double price, int quantity){
    return price * quantity;
}