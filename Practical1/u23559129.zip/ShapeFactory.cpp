#include "ShapeFactory.h"

ShapeFactory::~ShapeFactory() {
    // ensure proper cleanup in derived classes
}
